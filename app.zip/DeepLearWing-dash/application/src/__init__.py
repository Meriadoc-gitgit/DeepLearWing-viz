from .preprocess import *
from .simulationNACA0012 import *
from .plot_airfoil_performance import *
